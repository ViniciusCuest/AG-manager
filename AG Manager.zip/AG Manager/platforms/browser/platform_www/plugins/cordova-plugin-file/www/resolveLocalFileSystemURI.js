cordova.define("cordova-plugin-file.resolveLocalFileSystemURI", function(require, exports, module) { 
});
